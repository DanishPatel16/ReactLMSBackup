import "./App.css";
import ForgotPassword from "./page/forgetPassword";
import Home from "./page/Home";
import Login from "./page/login";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Profile from "./page/profile";

function App() {
  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route path="/Home" element={<Home />} />
          <Route path="/" element={<Login />} />
          <Route path="/ForgotPassword" element={<ForgotPassword />} />
          <Route path="/Profile" element={<Profile />} />
        </Routes>
      </BrowserRouter>
    </>
  );
}

export default App;
