import React, { useState } from "react";
import { Typography, Row, Col, Select } from "antd";
import { BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid, Legend } from "recharts"; 
import Navbar from "../Component/Navbar";


const { Title } = Typography;
const { Option } = Select;


const leaveData = {
  2023: {
    "Omkar": [
      { month: "January", annualLeave: 10, sickLeave: 5, casualLeave: 3, unpaidLeave: 1 },
      { month: "February", annualLeave: 8, sickLeave: 4, casualLeave: 2, unpaidLeave: 0 },
      { month: "March", annualLeave: 12, sickLeave: 2, casualLeave: 5, unpaidLeave: 3 },
      
    ],
    "Digpal": [
      { month: "January", annualLeave: 15, sickLeave: 6, casualLeave: 4, unpaidLeave: 2 },
      { month: "February", annualLeave: 12, sickLeave: 5, casualLeave: 1, unpaidLeave: 1 },
      { month: "March", annualLeave: 10, sickLeave: 3, casualLeave: 2, unpaidLeave: 0 },
      
    ],
  },
  2024: {
    "Omkar": [
      { month: "January", annualLeave: 8, sickLeave: 5, casualLeave: 2, unpaidLeave: 0 },
      { month: "February", annualLeave: 10, sickLeave: 3, casualLeave: 1, unpaidLeave: 1 },
      { month: "March", annualLeave: 7, sickLeave: 4, casualLeave: 2, unpaidLeave: 0 },
     
    ],
    "Digpal": [
      { month: "January", annualLeave: 12, sickLeave: 6, casualLeave: 3, unpaidLeave: 1 },
      { month: "February", annualLeave: 9, sickLeave: 4, casualLeave: 2, unpaidLeave: 1 },
      { month: "March", annualLeave: 10, sickLeave: 5, casualLeave: 0, unpaidLeave: 2 },
      
    ],
  },
};

const Home = () => {
  const [selectedYear, setSelectedYear] = useState(2023); 
  const [selectedEmployee, setSelectedEmployee] = useState("Omkar");
  const data = leaveData[selectedYear][selectedEmployee]; 

  const handleYearChange = (value) => {
    setSelectedYear(value); 
    setSelectedEmployee(Object.keys(leaveData[value])[0]); 
  };

  const handleEmployeeChange = (value) => {
    setSelectedEmployee(value); 
  };

  return (
    <>
      <Navbar />
      <Row style={{ height: "100vh", backgroundColor: "#fff", padding: "20px" }}>
        <Col
          span={24}
          style={{
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <Title level={2} style={{ textAlign: "center", color: "#333" }}>
            Monthly Employee Leave Dashboard
          </Title>
          

       
          <Select
            defaultValue={selectedYear}
            style={{ width: 120, marginBottom: "20px" }}
            onChange={handleYearChange}
          >
            <Option value={2023}>2023</Option>
            <Option value={2024}>2024</Option>
        
          </Select>

      
          <Select
            value={selectedEmployee}
            style={{ width: 120, marginBottom: "20px" }}
            onChange={handleEmployeeChange}
          >
            {Object.keys(leaveData[selectedYear]).map((employee) => (
              <Option key={employee} value={employee}>
                {employee}
              </Option>
            ))}
          </Select>

       
          <BarChart width={600} height={400} data={data} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="month" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Bar dataKey="annualLeave" stackId="a" fill="#0088FE" />
            <Bar dataKey="sickLeave" stackId="a" fill="#00C49F" />
            <Bar dataKey="casualLeave" stackId="a" fill="#FFBB28" />
            <Bar dataKey="unpaidLeave" stackId="a" fill="#FF8042" />
          </BarChart>
        </Col>
      </Row>
    </>
  );
};

export default Home;
